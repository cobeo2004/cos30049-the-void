# Create a new conda environment
conda create -n cos30049_env python=3.10.9
conda activate cos30049_env

# Check current environment
conda info --envs

#Check current python version
python --version
